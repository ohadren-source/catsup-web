import { useState, useEffect } from 'react'
import './App.css'

// ============================================================================
// BACKEND URL (Only this - no API keys in app!)
// ============================================================================

const BACKEND_URL = 'https://sauc-e-backend-production.up.railway.app'

const FREE_LESSON_LIMIT = 9

type Context = 'Science' | 'History' | 'Philosophy' | 'Technology' | 'Language'

const CONTEXTS: Context[] = ['Science', 'History', 'Philosophy', 'Technology', 'Language']

function App() {
  // ============================================================================
  // STATE
  // ============================================================================

  const [isSubscribed] = useState(false)
  const [lessonCount, setLessonCount] = useState(0)
  const [question, setQuestion] = useState('')
  const [context, setContext] = useState<Context>('Science')
  const [lesson, setLesson] = useState('')
  const [loading, setLoading] = useState(false)
  const [customerId] = useState<string | null>(null)

  // ============================================================================
  // INITIALIZATION
  // ============================================================================

  useEffect(() => {
    syncUsageCount('web-user')
  }, [])

  async function syncUsageCount(cid: string) {
    try {
      const response = await fetch(`${BACKEND_URL}/api/catsup/usage-status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId: cid || 'anonymous' }),
      })
      if (response.ok) {
        const data = await response.json()
        setLessonCount(data.usageCount || 0)
      }
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'unknown'
      console.log('Usage sync skipped:', msg)
    }
  }

  // ============================================================================
  // GET LESSON (Calls backend, NOT Claude directly)
  // ============================================================================

  async function handleGetLesson() {
    if (!question.trim()) {
      alert('Please describe what you want to learn')
      return
    }

    setLoading(true)

    try {
      const response = await fetch(`${BACKEND_URL}/api/catsup/get-lesson`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          customerId: customerId || 'anonymous',
          situation: question,
          context: context,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()

        if (response.status === 403) {
          alert('Limit Reached — Upgrade to Premium for unlimited learning')
          return
        }

        throw new Error(errorData.error || 'Failed to get lesson')
      }

      const data = await response.json()
      setLesson(data.wisdom || data.lesson)
      setLessonCount((prev) => prev + 1)
      setQuestion('')
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to process request'
      alert(msg)
    } finally {
      setLoading(false)
    }
  }

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="catsup-container">
      <header className="catsup-header">
        <h1 className="catsup-title">CATSUP</h1>
        <p className="catsup-subtitle">Socratic Learning</p>
        <p className="catsup-philosophy">Understanding = Questions / Ego</p>
      </header>

      {!isSubscribed && lessonCount > 0 && (
        <div className="catsup-usage">
          <span className="catsup-usage-text">
            {Math.max(0, FREE_LESSON_LIMIT - lessonCount)} free remaining
          </span>
        </div>
      )}

      <main className="catsup-content">
        <h2 className="catsup-section-title">Pick a Subject</h2>
        <div className="catsup-contexts">
          {CONTEXTS.map((c) => (
            <button
              key={c}
              className={`catsup-context-btn${context === c ? ' active' : ''}`}
              onClick={() => setContext(c)}
            >
              {c}
            </button>
          ))}
        </div>

        <h2 className="catsup-section-title">What Do You Want to Learn?</h2>
        <textarea
          className="catsup-input"
          placeholder="Ask a question or describe what you're curious about..."
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          rows={4}
        />

        <button
          className={`catsup-lesson-btn${loading ? ' disabled' : ''}`}
          onClick={handleGetLesson}
          disabled={loading}
        >
          {loading ? 'Thinking...' : 'Get Lesson'}
        </button>

        {lesson && (
          <div className="catsup-lesson-box">
            <h3 className="catsup-lesson-title">Lesson</h3>
            <p className="catsup-lesson-text">{lesson}</p>
          </div>
        )}

        <footer className="catsup-footer">
          <p className="catsup-footer-main">Runs on CATSUP Sauce 🔥 📚</p>
          <p className="catsup-footer-small">CATSUP is for Learning</p>
          <p className="catsup-footer-small">
            Sample: RELISH (Feelings) · BBQE (Safety)
          </p>
        </footer>
      </main>
    </div>
  )
}

export default App
